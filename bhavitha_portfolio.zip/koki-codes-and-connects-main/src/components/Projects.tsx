import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  ExternalLink, 
  Github, 
  Zap, 
  Droplets, 
  Battery,
  Cpu,
  Wifi,
  TrendingUp,
  MapPin,
  Calendar
} from "lucide-react";

const Projects = () => {
  const projects = [
    {
      id: 1,
      title: "Smart Waste-Heat Mobile Charger (TEG + IoT)",
      timeline: "October 2024",
      description: "Innovative thermoelectric generator-based energy harvester that converts waste heat into usable electrical energy for mobile device charging. Achieved 35% higher efficiency compared to conventional methods with potential for village-level scalability.",
      keyFeatures: [
        "Thermoelectric Generator (TEG) implementation",
        "IoT sensor integration for monitoring",
        "2-4W power generation from waste heat",
        "35% efficiency improvement",
        "Scalable design for rural applications"
      ],
      technologies: ["Arduino", "IoT Sensors", "TEG Modules", "C Programming", "Energy Harvesting"],
      metrics: {
        power: "2-4W",
        efficiency: "35% higher",
        scalability: "Village-level"
      },
      status: "Completed",
      category: "Renewable Energy",
      icon: Zap,
      gradientFrom: "from-yellow-500",
      gradientTo: "to-orange-600"
    },
    {
      id: 2,
      title: "Footstep & Solar-Powered Smart Irrigation System",
      timeline: "August 2025",
      description: "Dual-power irrigation system combining piezoelectric footstep energy generation with solar backup. Designed for sustainable agriculture with reliable power sourcing and intelligent water management.",
      keyFeatures: [
        "Piezoelectric footstep generator",
        "Solar panel backup system",
        "Smart irrigation control",
        "Battery storage management",
        "Weather-responsive automation"
      ],
      technologies: ["Piezoelectric Sensors", "Solar Panels", "MATLAB", "Battery Systems", "Smart Controllers"],
      metrics: {
        voltage: "3-5V per step",
        efficiency: "25-30%",
        reliability: "Dual-source"
      },
      status: "In Development",
      category: "Smart Agriculture",
      icon: Droplets,
      gradientFrom: "from-green-500",
      gradientTo: "to-blue-600"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "bg-accent text-accent-foreground";
      case "In Development":
        return "bg-warning text-warning-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <section id="projects" className="section-padding bg-background">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          
          {/* Section Header */}
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Featured Projects
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Innovative solutions in embedded systems and IoT that address real-world challenges 
              in renewable energy and sustainable technology.
            </p>
          </div>

          {/* Projects Grid */}
          <div className="space-y-12">
            {projects.map((project, index) => (
              <Card 
                key={project.id} 
                className={`shadow-card hover:shadow-card-hover transition-all duration-500 overflow-hidden ${
                  index % 2 === 0 ? 'animate-slide-in-left' : 'animate-slide-in-right'
                }`}
              >
                <div className="grid lg:grid-cols-5 gap-0">
                  
                  {/* Project Visual/Icon Section */}
                  <div className={`lg:col-span-2 bg-gradient-to-br ${project.gradientFrom} ${project.gradientTo} p-8 flex flex-col justify-center items-center text-white`}>
                    <div className="w-24 h-24 mb-6 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <project.icon className="w-12 h-12" />
                    </div>
                    <h3 className="text-xl font-bold text-center mb-4">{project.title}</h3>
                    
                    {/* Key Metrics */}
                    <div className="grid grid-cols-1 gap-3 w-full max-w-xs">
                      {Object.entries(project.metrics).map(([key, value]) => (
                        <div key={key} className="bg-white/10 rounded-lg p-3 backdrop-blur-sm text-center">
                          <div className="text-sm opacity-80 capitalize">{key}</div>
                          <div className="font-semibold">{value}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Project Details Section */}
                  <div className="lg:col-span-3">
                    <CardHeader className="pb-4">
                      <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                        <div>
                          <CardTitle className="text-2xl mb-2">{project.title}</CardTitle>
                          <div className="flex flex-wrap gap-2 items-center text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {project.timeline}
                            </div>
                            <span>•</span>
                            <Badge variant="outline">{project.category}</Badge>
                            <Badge className={getStatusColor(project.status)}>
                              {project.status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-6">
                      {/* Description */}
                      <p className="text-muted-foreground leading-relaxed">
                        {project.description}
                      </p>

                      {/* Key Features */}
                      <div>
                        <h4 className="font-semibold text-foreground mb-3">Key Features</h4>
                        <ul className="grid sm:grid-cols-2 gap-2">
                          {project.keyFeatures.map((feature, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Technologies */}
                      <div>
                        <h4 className="font-semibold text-foreground mb-3">Technologies Used</h4>
                        <div className="flex flex-wrap gap-2">
                          {project.technologies.map((tech) => (
                            <Badge key={tech} variant="secondary" className="text-xs">
                              {tech}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex flex-wrap gap-3 pt-4">
                        <Button variant="default" size="sm" className="bg-primary hover:bg-primary-dark">
                          <ExternalLink className="w-4 h-4 mr-2" />
                          View Details
                        </Button>
                        <Button variant="outline" size="sm">
                          <Github className="w-4 h-4 mr-2" />
                          Source Code
                        </Button>
                      </div>
                    </CardContent>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Call to Action */}
          <div className="text-center mt-16 animate-fade-in">
            <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-foreground mb-4">
                  Interested in Collaboration?
                </h3>
                <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                  I'm always excited to work on innovative projects that push the boundaries 
                  of embedded systems and IoT technology. Let's create something amazing together!
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button 
                    size="lg" 
                    className="bg-primary hover:bg-primary-dark"
                    onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  >
                    Get In Touch
                  </Button>
                  <Button variant="outline" size="lg">
                    <Github className="w-5 h-5 mr-2" />
                    View All Projects
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;