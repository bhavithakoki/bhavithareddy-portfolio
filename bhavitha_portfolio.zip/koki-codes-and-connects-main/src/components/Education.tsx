import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  GraduationCap, 
  Award, 
  Calendar, 
  MapPin, 
  Trophy,
  Users,
  Code2,
  BookOpen,
  Download,
  ExternalLink
} from "lucide-react";

const Education = () => {
  const educationTimeline = [
    {
      id: 1,
      level: "Bachelor's Degree",
      institution: "QIS College of Engineering & Technology",
      degree: "B.Tech in Electronics & Communication Engineering",
      duration: "2022 - 2026",
      cgpa: "8.4/10",
      status: "Current",
      location: "Ongole, Andhra Pradesh",
      highlights: [
        "Specialized in Embedded Systems and IoT",
        "Strong focus on renewable energy applications",
        "Active participation in technical projects",
        "Consistent academic excellence"
      ],
      icon: GraduationCap,
      color: "primary"
    },
    {
      id: 2,
      level: "Intermediate",
      institution: "Sri Sai Ram Junior College",
      degree: "M.P.C (Mathematics, Physics, Chemistry)",
      duration: "2020 - 2022",
      cgpa: "9.3/10",
      status: "Completed",
      location: "Andhra Pradesh",
      highlights: [
        "Excellent performance in core sciences",
        "Strong foundation in mathematics and physics",
        "Prepared for engineering entrance exams",
        "Leadership roles in academic activities"
      ],
      icon: BookOpen,
      color: "accent"
    },
    {
      id: 3,
      level: "Secondary School",
      institution: "Saraswathi High School",
      degree: "Secondary School Certificate",
      duration: "2019 - 2020",
      cgpa: "9.4/10",
      status: "Completed",
      location: "Andhra Pradesh",
      highlights: [
        "Outstanding academic performance",
        "Strong fundamentals in all subjects",
        "Active in extracurricular activities",
        "Recognition for academic excellence"
      ],
      icon: Award,
      color: "warning"
    }
  ];

  const certifications = [
    {
      title: "C for Everyone",
      provider: "Coursera",
      category: "Programming",
      skills: ["C Programming", "Data Structures", "Algorithms"],
      date: "2024"
    },
    {
      title: "Python Programming Certification", 
      provider: "Internshala",
      category: "Programming",
      skills: ["OOP", "File Handling", "Automation", "Python"],
      date: "2024"
    },
    {
      title: "Embedded Systems Course",
      provider: "MindLuster", 
      category: "Hardware",
      skills: ["Microcontrollers", "Real-time Interface", "Hardware Programming"],
      date: "2024"
    }
  ];

  const achievements = [
    {
      title: "IEEE QIS MTTS Treasurer",
      organization: "IEEE Student Branch",
      period: "January 2025 - Present",
      description: "Leading technical workshops, improving junior member engagement by 25%, and coordinating various IEEE activities.",
      icon: Users,
      impact: "25% increase in member engagement"
    },
    {
      title: "ByteXL Coding Competition",
      organization: "ByteXL",
      period: "April 2025",
      description: "Participated in competitive programming competition, enhancing problem-solving skills and algorithmic thinking.",
      icon: Code2,
      impact: "Enhanced problem-solving skills"
    }
  ];

  const getColorClasses = (color: string) => {
    switch (color) {
      case "primary":
        return "bg-primary/10 text-primary border-primary/20";
      case "accent": 
        return "bg-accent/10 text-accent border-accent/20";
      case "warning":
        return "bg-warning/10 text-warning border-warning/20";
      default:
        return "bg-muted text-muted-foreground border-border";
    }
  };

  return (
    <section id="education" className="section-padding bg-muted/30">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          
          {/* Section Header */}
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Education & Achievements
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Academic journey marked by consistent excellence and continuous learning 
              in electronics, communication, and emerging technologies.
            </p>
          </div>

          {/* Education Timeline */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-foreground mb-8 text-center">Academic Timeline</h3>
            <div className="relative">
              {/* Timeline Line */}
              <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 top-0 bottom-0 w-0.5 bg-border"></div>
              
              <div className="space-y-12">
                {educationTimeline.map((education, index) => (
                  <div 
                    key={education.id}
                    className={`relative flex items-start ${
                      index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                    } animate-fade-in`}
                    style={{ animationDelay: `${index * 200}ms` }}
                  >
                    {/* Timeline Dot */}
                    <div className={`absolute left-4 md:left-1/2 transform md:-translate-x-1/2 w-8 h-8 rounded-full border-4 bg-background flex items-center justify-center ${getColorClasses(education.color)}`}>
                      <education.icon className="w-4 h-4" />
                    </div>

                    {/* Content Card */}
                    <div className={`ml-16 md:ml-0 ${index % 2 === 0 ? 'md:mr-8 md:text-right' : 'md:ml-8'} md:w-1/2`}>
                      <Card className="shadow-card hover:shadow-card-hover transition-all duration-300">
                        <CardContent className="p-6">
                          <div className="flex flex-wrap gap-2 mb-3">
                            <Badge className={getColorClasses(education.color)}>
                              {education.status}
                            </Badge>
                            <Badge variant="outline">
                              {education.level}
                            </Badge>
                          </div>
                          
                          <h4 className="text-xl font-semibold text-foreground mb-2">
                            {education.degree}
                          </h4>
                          
                          <p className="text-lg font-medium text-muted-foreground mb-2">
                            {education.institution}
                          </p>
                          
                          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-4">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {education.duration}
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="w-4 h-4" />
                              {education.location}
                            </div>
                            <div className="flex items-center gap-1 font-semibold text-primary">
                              <Trophy className="w-4 h-4" />
                              CGPA: {education.cgpa}
                            </div>
                          </div>

                          <ul className="space-y-1 text-sm">
                            {education.highlights.map((highlight, idx) => (
                              <li key={idx} className="flex items-start gap-2 text-muted-foreground">
                                <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                                {highlight}
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Certifications & Courses */}
          <div className="mb-16 animate-fade-in">
            <h3 className="text-2xl font-bold text-foreground mb-8 text-center">Certifications & Courses</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {certifications.map((cert) => (
                <Card key={cert.title} className="shadow-card hover:shadow-card-hover transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Award className="w-6 h-6 text-primary" />
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {cert.date}
                      </Badge>
                    </div>
                    
                    <h4 className="font-semibold text-foreground mb-2">{cert.title}</h4>
                    <p className="text-sm text-muted-foreground mb-4">{cert.provider}</p>
                    
                    <div className="space-y-2">
                      <p className="text-xs text-muted-foreground font-medium">Skills Gained:</p>
                      <div className="flex flex-wrap gap-1">
                        {cert.skills.map((skill) => (
                          <Badge key={skill} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Leadership & Activities */}
          <div className="mb-16 animate-fade-in">
            <h3 className="text-2xl font-bold text-foreground mb-8 text-center">Leadership & Activities</h3>
            <div className="grid md:grid-cols-2 gap-6">
              {achievements.map((achievement) => (
                <Card key={achievement.title} className="shadow-card hover:shadow-card-hover transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                        <achievement.icon className="w-6 h-6 text-accent" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-foreground mb-1">{achievement.title}</h4>
                        <p className="text-sm text-muted-foreground mb-2">{achievement.organization}</p>
                        <p className="text-sm text-muted-foreground mb-3">{achievement.period}</p>
                        <p className="text-sm text-muted-foreground mb-3">{achievement.description}</p>
                        <Badge className="bg-accent/10 text-accent">
                          Impact: {achievement.impact}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Resume Download CTA */}
          <div className="text-center animate-fade-in">
            <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-foreground mb-4">
                  Download My Complete Resume
                </h3>
                <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                  Get detailed information about my academic background, technical skills, 
                  projects, and achievements in a comprehensive PDF format.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button 
                    size="lg" 
                    className="bg-primary hover:bg-primary-dark"
                    onClick={() => window.open("#", "_blank")}
                  >
                    <Download className="w-5 h-5 mr-2" />
                    Download Resume (PDF)
                  </Button>
                  <Button variant="outline" size="lg">
                    <ExternalLink className="w-5 h-5 mr-2" />
                    View Online Version
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;