import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Mail, 
  Phone, 
  MapPin, 
  Linkedin, 
  Github,
  Heart,
  ArrowUp
} from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const quickLinks = [
    { label: "About", id: "about" },
    { label: "Projects", id: "projects" },
    { label: "Education", id: "education" },
    { label: "Contact", id: "contact" }
  ];

  const socialLinks = [
    {
      icon: Mail,
      label: "Email",
      href: "mailto:bhavithareddykoki@gmail.com",
      color: "hover:text-red-500"
    },
    {
      icon: Linkedin,
      label: "LinkedIn", 
      href: "#",
      color: "hover:text-blue-600"
    },
    {
      icon: Github,
      label: "GitHub",
      href: "#",
      color: "hover:text-gray-600"
    }
  ];

  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4 lg:px-6">
        
        {/* Main Footer Content */}
        <div className="py-12">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            
            {/* Brand Section */}
            <div className="lg:col-span-2">
              <h3 className="text-2xl font-bold mb-4">Koki Bhavitha Reddy</h3>
              <p className="text-background/80 mb-6 leading-relaxed">
                Electronics & Communication Engineering student passionate about embedded systems, 
                IoT innovations, and renewable energy solutions. Currently pursuing B.Tech at 
                QIS College of Engineering & Technology.
              </p>
              
              {/* Contact Info */}
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-background/70">
                  <MapPin className="w-4 h-4" />
                  <span>Ongole, Andhra Pradesh, India</span>
                </div>
                <div className="flex items-center gap-2 text-background/70">
                  <Phone className="w-4 h-4" />
                  <a href="tel:+919030305833" className="hover:text-primary transition-colors">
                    +91 9030305833
                  </a>
                </div>
                <div className="flex items-center gap-2 text-background/70">
                  <Mail className="w-4 h-4" />
                  <a 
                    href="mailto:bhavithareddykoki@gmail.com" 
                    className="hover:text-primary transition-colors break-all"
                  >
                    bhavithareddykoki@gmail.com
                  </a>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                {quickLinks.map((link) => (
                  <li key={link.id}>
                    <button
                      onClick={() => scrollToSection(link.id)}
                      className="text-background/70 hover:text-primary transition-colors"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
                <li>
                  <a 
                    href="#" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-background/70 hover:text-primary transition-colors"
                  >
                    Resume (PDF)
                  </a>
                </li>
              </ul>
            </div>

            {/* Connect Section */}
            <div>
              <h4 className="text-lg font-semibold mb-4">Connect With Me</h4>
              <div className="space-y-4">
                <p className="text-sm text-background/70">
                  Let's connect and explore opportunities in embedded systems and IoT!
                </p>
                
                {/* Social Links */}
                <div className="flex gap-3">
                  {socialLinks.map((social) => (
                    <Button
                      key={social.label}
                      variant="outline"
                      size="icon"
                      className="border-background/20 text-background hover:bg-primary hover:border-primary hover:text-primary-foreground transition-all duration-300"
                      asChild
                    >
                      <a
                        href={social.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={social.label}
                      >
                        <social.icon className="w-4 h-4" />
                      </a>
                    </Button>
                  ))}
                </div>

                {/* Scroll to Top Button */}
                <Button
                  onClick={scrollToTop}
                  variant="outline"
                  size="sm"
                  className="border-background/20 text-background hover:bg-primary hover:border-primary hover:text-primary-foreground transition-all duration-300"
                >
                  <ArrowUp className="w-4 h-4 mr-2" />
                  Back to Top
                </Button>
              </div>
            </div>
          </div>
        </div>

        <Separator className="bg-background/20" />

        {/* Bottom Footer */}
        <div className="py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-background/70">
            <div className="flex items-center gap-1">
              <span>© {currentYear} Koki Bhavitha Reddy. Made with</span>
              <Heart className="w-4 h-4 text-red-500 fill-current" />
              <span>and passion for innovation.</span>
            </div>
            
            <div className="flex items-center gap-6">
              <span>B.Tech ECE Student</span>
              <span>•</span>
              <span>Available for Internships</span>
              <span>•</span>
              <span>Open to Collaboration</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;