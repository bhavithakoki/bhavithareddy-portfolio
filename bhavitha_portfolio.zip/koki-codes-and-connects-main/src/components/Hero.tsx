import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { ChevronDown, Download, Mail, MapPin } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";
import profilePhoto from "@/assets/profile-photo.jpg";

const Hero = () => {
  const [currentText, setCurrentText] = useState("");
  const [textIndex, setTextIndex] = useState(0);
  
  const taglines = [
    "Electronics & Communication Engineering Student",
    "Embedded Systems Enthusiast", 
    "IoT Innovator",
    "Renewable Energy Advocate"
  ];

  useEffect(() => {
    const typeText = () => {
      const fullText = taglines[textIndex];
      let charIndex = 0;
      
      const typeInterval = setInterval(() => {
        setCurrentText(fullText.slice(0, charIndex + 1));
        charIndex++;
        
        if (charIndex === fullText.length) {
          clearInterval(typeInterval);
          setTimeout(() => {
            setTextIndex((prev) => (prev + 1) % taglines.length);
          }, 2000);
        }
      }, 100);
      
      return typeInterval;
    };
    
    const interval = typeText();
    return () => clearInterval(interval);
  }, [textIndex]);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroBg}
          alt="Professional tech background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/90 via-primary-dark/80 to-primary/70"></div>
        <div className="absolute inset-0 bg-black/20"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 lg:px-6 text-center">
        <div className="max-w-4xl mx-auto animate-fade-in">
          
          {/* Profile Image */}
          <div className="mb-8 animate-float">
            <div className="w-32 h-32 md:w-40 md:h-40 mx-auto rounded-full bg-white/10 backdrop-blur-sm border-4 border-white/20 flex items-center justify-center shadow-2xl">
              <Avatar className="w-28 h-28 md:w-36 md:h-36">
                <AvatarImage 
                  src={profilePhoto} 
                  alt="Koki Bhavitha Reddy - Professional headshot"
                  className="object-cover"
                />
                <AvatarFallback className="text-2xl md:text-3xl font-bold bg-gradient-to-br from-accent to-accent-light text-white">
                  KR
                </AvatarFallback>
              </Avatar>
            </div>
          </div>

          {/* Name */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 animate-slide-in-left">
            Koki Bhavitha Reddy
          </h1>

          {/* Animated Tagline */}
          <div className="h-16 md:h-20 mb-8 animate-slide-in-right">
            <p className="text-xl md:text-2xl lg:text-3xl text-white/90 font-medium">
              {currentText}
              <span className="animate-blink text-accent">|</span>
            </p>
          </div>

          {/* Location & Status */}
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8 mb-8 text-white/80">
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              <span className="text-lg">Ongole, Andhra Pradesh, India</span>
            </div>
            <div className="hidden md:block w-px h-6 bg-white/30"></div>
            <div className="text-lg">
              B.Tech ECE Student | CGPA: 8.4/10
            </div>
          </div>

          {/* Description */}
          <p className="text-lg md:text-xl text-white/90 mb-12 max-w-3xl mx-auto leading-relaxed">
            Passionate about creating innovative solutions in embedded systems and IoT. 
            Focused on renewable energy applications and smart automation technologies 
            that make a real-world impact.
          </p>

          {/* Call to Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              className="bg-white text-primary hover:bg-white/90 font-semibold px-8 py-4 text-lg shadow-button"
              onClick={() => scrollToSection("projects")}
            >
              View My Projects
            </Button>
            
            <Button
              variant="outline"
              size="lg"
              className="border-2 border-white text-white hover:bg-white hover:text-primary font-semibold px-8 py-4 text-lg backdrop-blur-sm"
              onClick={() => window.open("#", "_blank")}
            >
              <Download className="h-5 w-5 mr-2" />
              Download Resume
            </Button>
            
            <Button
              variant="outline"
              size="lg"
              className="border-2 border-white text-white hover:bg-white hover:text-primary font-semibold px-8 py-4 text-lg backdrop-blur-sm"
              onClick={() => scrollToSection("contact")}
            >
              <Mail className="h-5 w-5 mr-2" />
              Get In Touch
            </Button>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <button
            onClick={() => scrollToSection("about")}
            className="text-white/70 hover:text-white transition-colors"
            aria-label="Scroll to About section"
          >
            <ChevronDown className="h-8 w-8" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;