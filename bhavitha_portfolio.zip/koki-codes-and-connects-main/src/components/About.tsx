import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Cpu, 
  Wifi, 
  Zap, 
  Code, 
  Brain, 
  Target,
  BookOpen,
  Award,
  Lightbulb
} from "lucide-react";

const About = () => {
  const skills = [
    { name: "Python", level: 85, category: "Programming" },
    { name: "C Programming", level: 80, category: "Programming" },
    { name: "Arduino", level: 90, category: "Hardware" },
    { name: "MATLAB", level: 75, category: "Analysis" },
    { name: "Embedded Systems", level: 85, category: "Core" },
    { name: "IoT Development", level: 88, category: "Core" },
  ];

  const interests = [
    { 
      icon: Zap, 
      title: "Renewable Energy Systems", 
      description: "Innovative energy harvesting solutions" 
    },
    { 
      icon: Cpu, 
      title: "Embedded Systems", 
      description: "Microcontroller programming & interfacing" 
    },
    { 
      icon: Wifi, 
      title: "IoT Innovation", 
      description: "Smart connected device development" 
    },
    { 
      icon: Lightbulb, 
      title: "Smart Automation", 
      description: "Intelligent system design & implementation" 
    }
  ];

  const achievements = [
    { icon: Award, text: "IEEE QIS MTTS Treasurer (2025)" },
    { icon: Target, text: "ByteXL Coding Competition Participant" },
    { icon: BookOpen, text: "Multiple Technical Certifications" },
    { icon: Brain, text: "CGPA: 8.4/10 Academic Excellence" }
  ];

  return (
    <section id="about" className="section-padding bg-muted/30">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="max-w-6xl mx-auto">
          
          {/* Section Header */}
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              About Me
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Passionate Electronics & Communication Engineering student with a focus on 
              innovative embedded systems and sustainable technology solutions.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-start">
            
            {/* Left Column - Bio & Philosophy */}
            <div className="space-y-8 animate-slide-in-left">
              <Card className="shadow-card hover:shadow-card-hover transition-all duration-300">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-semibold mb-6 text-foreground">My Journey</h3>
                  <div className="space-y-4 text-muted-foreground leading-relaxed">
                    <p>
                      As a dedicated B.Tech ECE student at QIS College of Engineering & Technology, 
                      I've maintained a strong academic record with a CGPA of 8.4/10 while actively 
                      pursuing my passion for embedded systems and IoT innovations.
                    </p>
                    <p>
                      My expertise lies in developing practical solutions that bridge the gap between 
                      theoretical knowledge and real-world applications. I'm particularly interested 
                      in renewable energy systems and sustainable technology that can make a positive 
                      impact on society.
                    </p>
                    <p>
                      Through hands-on projects and continuous learning, I strive to create innovative 
                      solutions that address modern challenges while contributing to a more connected 
                      and sustainable future.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Technical Skills */}
              <Card className="shadow-card hover:shadow-card-hover transition-all duration-300">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-semibold mb-6 text-foreground">Technical Skills</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {skills.map((skill) => (
                      <div key={skill.name} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="font-medium text-foreground">{skill.name}</span>
                          <Badge variant="outline" className="text-xs">
                            {skill.category}
                          </Badge>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full transition-all duration-1000 ease-out"
                            style={{ width: `${skill.level}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Interests & Achievements */}
            <div className="space-y-8 animate-slide-in-right">
              
              {/* Core Interests */}
              <Card className="shadow-card hover:shadow-card-hover transition-all duration-300">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-semibold mb-6 text-foreground">Areas of Interest</h3>
                  <div className="grid gap-6">
                    {interests.map((interest) => (
                      <div key={interest.title} className="flex gap-4">
                        <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                          <interest.icon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground mb-1">{interest.title}</h4>
                          <p className="text-muted-foreground text-sm">{interest.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Key Achievements */}
              <Card className="shadow-card hover:shadow-card-hover transition-all duration-300">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-semibold mb-6 text-foreground">Key Achievements</h3>
                  <div className="grid gap-4">
                    {achievements.map((achievement) => (
                      <div key={achievement.text} className="flex items-center gap-3">
                        <div className="flex-shrink-0 w-8 h-8 bg-accent/10 rounded-full flex items-center justify-center">
                          <achievement.icon className="h-4 w-4 text-accent" />
                        </div>
                        <span className="text-muted-foreground">{achievement.text}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card className="shadow-card hover:shadow-card-hover transition-all duration-300">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-semibold mb-6 text-foreground">Quick Stats</h3>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary mb-2">8.4</div>
                      <div className="text-sm text-muted-foreground">Current CGPA</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary mb-2">2+</div>
                      <div className="text-sm text-muted-foreground">Major Projects</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary mb-2">5+</div>
                      <div className="text-sm text-muted-foreground">Certifications</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary mb-2">2026</div>
                      <div className="text-sm text-muted-foreground">Graduation Year</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;